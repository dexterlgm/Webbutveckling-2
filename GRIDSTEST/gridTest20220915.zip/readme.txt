All HTML är klar i index.html, med undantag för att du kan behöva tilldela id och/eller klasser. CSS-filen om behövs får du göra från början.

Den beskrivande texten i rutorna använder Times New Roman. All annan text använder Verdana.

Bakgrundsbilden (Wynton-Marsalis.jpg) finns förstås i mappen images.

Bakgrundsfärgen för textrutorna är #D4759F. Texten är vit. OK, om man ska vara riktigt noga så har rubrikerna i rutorna färgen #EEE.

Storlekar, padding, margins osv bestämmer DU. Anpassa allt så att det blir så likt förlagan som möjligt. Kolla bifogade screenshots.

Layouten ska vara dynamisk i den bemärkelsen att textrutornas bredd skall anpassas efter skärmens storlek. Mindre skärm = smalare kolumner, större skärm = bredare kolumner. Du behöver INTE skriva mediaqueries (@media).

När du är klar lämnar du in en zippad fil på Classroom och går ut ur salen.